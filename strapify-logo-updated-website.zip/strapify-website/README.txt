STRAPIFY WEBSITE — LOGO UPDATED

Open index.html in a browser. Keep strapify-logo.jpeg in the same folder as index.html.

The supplied Strapify logo is used in the website header and footer.

This is a front-end prototype. Real secure uploads, live order submission, database, payments, email notifications, and admin dashboard still require backend integration.
